package com.youlu.ignore.sms;

import com.alibaba.jvm.sandbox.api.Information;
import com.alibaba.jvm.sandbox.api.Module;
import com.alibaba.jvm.sandbox.api.ProcessController;
import com.alibaba.jvm.sandbox.api.annotation.Command;
import com.alibaba.jvm.sandbox.api.listener.ext.Advice;
import com.alibaba.jvm.sandbox.api.listener.ext.AdviceListener;
import com.alibaba.jvm.sandbox.api.listener.ext.EventWatchBuilder;
import com.alibaba.jvm.sandbox.api.resource.ModuleEventWatcher;
import org.kohsuke.MetaInfServices;

import javax.annotation.Resource;

/**
 * @author zhushilong
 */
@MetaInfServices(Module.class)
@Information(id = "ignore",author = "一朵彼岸花",version = "0.0.1")
public class IgnoreSmsModule implements Module {

    @Resource
    private ModuleEventWatcher moduleEventWatcher;

    @Command("ignoreSms")
    public void ignoreSms() {
        new EventWatchBuilder(moduleEventWatcher)
                .onClass("com.niceloo.mc.service.api.impl.AliSMSApi")
                .onBehavior("send")
                .onWatch(new AdviceListener() {
                    @Override
                    protected void before(Advice advice) throws Throwable {
                        // 这里的代码意义是：改变原方法抛出异常的行为，变更为立即返回；void返回值用null表示
                        ProcessController.returnImmediately(null);
                    }
                });

    }

}
